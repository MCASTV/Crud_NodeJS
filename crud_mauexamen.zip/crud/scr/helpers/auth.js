const helpers ={};

helpers.isAuthenticated = (req,res, next)=>{
    if(req.isAuthenticated()){
        return next();
    }
    req.flash('error_msg','Usuario no autentificado');
    res.redirect('/users/signin');
}
module.exports=helpers;