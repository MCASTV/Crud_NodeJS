const router = require('express').Router();

router.get('/', (req, res)=>{
    res.render('Index');//envia a la pagina un texto
});

router.get('/about', (req, res)=>{
    res.render('about');//envia a la pagina un texto
});
module.exports = router;