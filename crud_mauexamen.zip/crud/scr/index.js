//modulos
const express= require('express');
const path= require('path');//modulo que permite concatener ruta
const exphbs= require('express-handlebars');
const methOverride= require('method-override');//permite usar methodos a parte de get y post
const session= require('express-session');//permite guarda variable de sesion
const flash =require('connect-flash');

const passport = require('passport');//llamas passport

//inicualizar
const app = express();
require('./database');
require('./config/passport');
//Configuraciones
app.set('port',process.env.PORT || 3000);
app.set('views',path.join(__dirname, 'views'));

//metodos 
app.engine('.hbs',exphbs.engine({
    defaultLayout:'main',
    layoutsDir: path.join(app.get('views'),'layouts'),
    partialsDir: path.join(app.get('views'),'partials'),
    extname: '.hbs'
}));
app.set('view engine', 'hbs');
//Middlewares  funciones que son ejecutadas antes que lleguen al servidor
app.use(express.urlencoded({extends:false}));
app.use(methOverride('_method'));
app.use(session({
    secret: 'myappsecret',
    resave: true,
    saveUninitialized:true,
}));
app.use(passport.initialize());//Inicializar
app.use(passport.session());//Sesion activa
app.use(flash());
//Agregar el middleware
//Variables globales
//agregar variables global
app.use((req,res,next) => {
    //Variable global que guarda mensaje de success
    res.locals.success_msg = req.flash('success_msg');
    //Variable global que guarda mensaje de error
    res.locals.error_msg = req.flash('error_msg');
    res.locals.error = req.flash('error');
    res.locals.user = req.user || null;
    next();
})
//variables globales


//routes
app.use(require('./routes/index'));
app.use(require('./routes/notes'));
app.use(require('./routes/users'));
//archivos estaticos
app.use(express.static(path.join(__dirname, 'public')));
//servidor arriba

app.listen(app.get('port'), () =>{
console.log('Servidor arriba ',app.get('port'));
})
