//Estrategia para autentificar el usuario
//Requiero passport
const passport = require('passport');
//Crear tu propia estrategia
const LocalStrategy =require('passport-local').Strategy;
//Constante requiero  el modelo
const User = require('../models/User');

//Estrategica de autentificacion
passport.use(new LocalStrategy(
    {
        //Recibe User Y Password
        //Renombrar el dato username
        usernameField:'email'

    },async(email,password, done) =>{
        //Ver si el usuario existe
        const user = await  User.findOne({email:email});
       
        if(!user){
            return done(null,false,{message:'El usuario no exite'});
        }else{
            const match = await user.matchPassword(password);//Compara la contraseña 
            //Si existe la contraseña
            if(match){
                return done(null,user);
            }else{//Notifica  si  la contraseña 
                return done(null,false,{message:"Contraseña incorrecta"});
            }
        }
    }
));


//Serializar al usuario

passport.serializeUser((user, done)=>{
    done(null,user.id);
});

//Deseralizar al usuario
passport.deserializeUser((id, done)=>{
    User.findById(id, (err,user)=>{
        done(err,user);
    });
});
