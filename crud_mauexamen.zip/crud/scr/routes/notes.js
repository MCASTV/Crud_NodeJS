const { route } = require('express/lib/application');
const res = require('express/lib/response');
const Notes = require('../models/Notes');
const {isAuthenticated} = require('../helpers/auth');


const router = require('express').Router();
const Note =require("../models/Notes");
// get es la que manda la ruta
//Muestra la vista
router.get('/notes/add',isAuthenticated, (req, res) => {
    res.render('notes/new-notes');
})

router.post('/notes/new-notes',isAuthenticated, async(req, res) =>{
    //inicializar el objecto donde va guardar la vista
    //const obj = JSON.parse(JSON.stringify(req.body));
    //console.log(obj);
    //res.send('Datos recibidos correctamente');

    const {titulo,descripcion,estado,encargado} = req.body;
    const error = [];
    if(!titulo){
        error.push({text:'Por favor ingresa un valor en el titulo'}); 
        
    }

    if(!descripcion){
        error.push({texto:'por favor ingresa un valor en la descripcion'});
    }
    if(error.length > 0){
        res.render('notes/new-notes',{
            error,
            titulo,
            descripcion,
            estado,
            encargado
        });
    }else{
       // res.send('todo bien');
       const NewNotes = new Notes({titulo, descripcion,estado,encargado});
       //console.log(NewNotes);
       //res.send('ok');
       NewNotes.user = req.user.id;
      
       //indica que esta accion la hace asincronica
       await NewNotes.save();
       req.flash('success_msg','Nota agregada correctamente');
       res.redirect('/notes')

    }
});
router.get('/notes',isAuthenticated,async(req, res)=>{
    const notes = await Notes.find({user: req.user.id}).sort({fecha:'desc'}).lean();
    res.render('notes/all-notes',{notes});
});

router.get('/notes/edit/:id',isAuthenticated, async(req, res )=>{
    //consulta a la base
    const note = await Note.findById(req.params.id).lean();
    
    res.render('notes/edit-notes',{note});
});

router.put('/notes/edit-note/:id',isAuthenticated, async(req,res)=>{
    const{titulo,descripcion,estado,encargado}=req.body;
    await Note.findByIdAndUpdate(req.params.id,{titulo,descripcion,estado,encargado});
    req.flash('success_msg','Nota edita correctamente');
    res.redirect('/notes')
})

router.delete('/notes/delete/:id',isAuthenticated,async (req,res) =>{
    await Note.findByIdAndDelete(req.params.id);
    req.flash('success_msg','Nota eliminada correctamente');
    res.redirect('/notes');
})

module.exports = router;