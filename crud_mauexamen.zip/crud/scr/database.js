//Crear conexion a base de datos

// se tiene que levanrar el denominio de mongo

const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/notes_db_app',)
    .then(db => console.log('Base de datos conetados'))
    .catch(er => console.error(err));