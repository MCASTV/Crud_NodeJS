const router = require('express').Router();
const User = require('../models/User');
//Llamar a llamar a passport
const passport=require('passport');
router.get('/users/signin', (req, res)=>{//loggin ingreso usuario
    res.render('users/signin');
});

router.post('/users/signin',passport.authenticate('local',{
   //Si funciono
    successRedirect:'/notes',
    //Redirige a la pantalla de inicio
    failureRedirect:'/users/signin',
    //Regresa los errores
    failureFlash:true
}));


router.get('/users/signup', (req, res)=>{//Formulario usuario
    res.render('users/signup');
});


router.post('/users/signup', async (req, res)=>{
//console.log(req.body);
//res.send("ok");
const {nombre,email,password,c_password}=req.body;
const errors =[];
//nombre no esta vacio
if(nombre<=0){
    errors.push({text:'Inserte un nombre'});
}
//correo no esta vacio
if(email<=0){
    errors.push({text:'Inserte un correo'});
}
//contraseña no esta vacia
if(password<=0){
    errors.push({text:'Inserta una contraseña'});
}
//contraseña mayor a 4 digitos
if(password.lenght==4){
    errors.push({text:'La contraseña tiene que ser mayor a 4'});
}
//contraseña concidan
if(password != c_password){
    errors.push({text:'Las contraseña no coinciden'});
}

if(errors.length >0){
    res.render('users/signup',{errors,nombre,email,password,c_password});
}else{
    //console.log(req.body);
    //  res.send("okparse");
    const correoUser = await User.findOne({email:email});
    if(correoUser){
        req.flash('error_msg','El correo ya lo usaro lastima');
        res.redirect('signin');
    }
    const newUser = new User({nombre,email,password,c_password});
    newUser.password = await newUser.encryptPassword(password);
    await newUser.save();
    req.flash('success_msg','YA ESTA REGISTRADO COMPA ');
    //res.redirect('signin');
    //res.send("ok");
    res.redirect('signin');


}

});

//GET Y POST

router.get('/users/logout', (req,res)=>{
req.logout();
res.redirect('/');
});

module.exports = router;